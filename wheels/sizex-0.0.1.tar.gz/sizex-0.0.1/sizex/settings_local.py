DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'sizex',
    }
}

CDN_DOMAIN = '127.0.0.1:8000'
