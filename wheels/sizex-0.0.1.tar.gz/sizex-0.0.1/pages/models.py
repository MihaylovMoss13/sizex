import re

from django.urls import reverse
from django.db import models
from django.conf import settings

from mptt.models import MPTTModel, TreeForeignKey
from ckeditor_uploader.fields import RichTextUploadingField
from django.utils.translation import ugettext as _

from .changer import changer


class Domain(models.Model):
    domain = models.CharField(verbose_name=_(u'Домен'), max_length=255, blank=True)

    def __str__(self):
        return self.domain

    class Meta:
        verbose_name = _(u'Домен')
        verbose_name_plural = _(u'Домены')


class Pages(MPTTModel):
    # Base parameters
    name = models.CharField(verbose_name=_(u'Название страницы'), max_length=255)
    h1 = models.CharField(verbose_name=_(u'h1 страницы'), max_length=255, blank=True, null=True)
    alias = models.CharField(verbose_name=_(u'Ссылка на страницу'), max_length=255, blank=True)
    replace = models.BooleanField(verbose_name=_(u'Не подменять пустой alias'), default=False)
    parent = TreeForeignKey(
        'self',
        null=True,
        blank=True,
        related_name='children',
        verbose_name=u'Родитель',
        on_delete=models.CASCADE
    )
    text = RichTextUploadingField(verbose_name=_(u'Текст страницы'), blank=True, null=True)
    domain = models.ForeignKey(Domain, verbose_name=_(u'Домен'), on_delete=models.CASCADE, default=1)

    # Meta parameters
    title = models.CharField(verbose_name=_(u'Заголовок страницы'), max_length=1000, blank=True)
    meta_d = models.CharField(verbose_name=_(u'Ключевое описание'), max_length=1000, blank=True)

    # Active
    status = models.BooleanField(verbose_name=_(u'Вкл?'), default=False)

    created_at = models.DateTimeField(verbose_name=_(u'Дата и время создания'), auto_now_add=True)
    update_at = models.DateTimeField(verbose_name=_(u'Дата и время последнего обновления'), auto_now=True)

    def clear_cache(self):
        """
        return '<a href="%s"><span class="icon-refresh"></span></a>' % reverse(
            'clear_cache',
            kwargs={'classtype': 'page', 'pk': self.id}
        )
        """
        return ''

    clear_cache.allow_tags = True
    clear_cache.short_description = _('Кэш')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = _(u'Страницы сайта')
        ordering = ['-update_at']

    def get_children(self):
        return Pages.objects.filter(parent=self).filter(status=True)

    def get_unique_alias(self, alias, num=0):
        num += 1
        pages = Pages.objects.filter(alias=alias)
        if len(pages) != 0:
            if len(pages) == 1 and pages[0].id == self.id:
                return alias

            alias = alias + '-' + str(num)
            return self.get_unique_alias(alias, num)
        return alias

    def get_prealias(self, alias, obj):
        if obj.parent:
            if obj.parent.alias not in ['verhnee_menyu', 'levoe_menyu']:
                alias = obj.parent.alias + '/' + self.alias
                self.get_prealias(alias, obj.parent)
        return alias

    def change_alias(self):
        alias = self.get_prealias('', self)

        for item in self.name.lower():
            if item in changer:
                alias += changer[item]
            else:
                alias += item
        alias = re.sub(u'[^A-Za-z0-9-/_\s]+', '', alias)
        alias = re.sub(u'-{2,10}', '-', alias)
        self.alias = self.get_unique_alias(alias)

    def save(self, *args, **kwargs):
        if not self.title:
            self.title = self.name

        if not self.h1:
            self.h1 = self.name

        if self.alias == '' and not self.replace:
            self.change_alias()

        if hasattr(self, 'title_en'):
            if not self.title_en:
                self.title_en = self.name_en

            if not self.h1_en:
                self.h1_en = self.name_en

        super(Pages, self).save(*args, **kwargs)

    def get_absolute_url(self):
        alias = reverse('page', kwargs={'slug': self.alias}) if self.alias else ''
        return 'http://' + self.domain.domain + alias

    def get_host_url(self):
        if self.alias:
            return 'http://' + self.domain + reverse('page', kwargs={'slug': self.alias})
        else:
            return 'http://' + self.domain


CODE_CHOICES = (
    (u'0', 301),
    (u'1', 302),
)

class Redirect(models.Model):
    fr = models.CharField(verbose_name=_(u'Откуда'), max_length=1023)
    to = models.CharField(verbose_name=_(u'Куда'), max_length=1023)
    code = models.CharField(verbose_name=_(u'Код'), max_length=255, choices=CODE_CHOICES, default='0')
    domain = models.ForeignKey(Domain, verbose_name=_(u'Домен'), on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name = _(u'Редирект')
        verbose_name_plural = _(u'Редиректы')



class Feedback(models.Model):
    name = models.CharField(verbose_name=_(u'Имя'), max_length=255)
    email = models.CharField(verbose_name=_(u'Электронная почта'), max_length=255, blank=True)
    phone = models.CharField(verbose_name=_(u'Телефон'), max_length=255)
    comment = models.TextField(verbose_name=_(u'Комментарий'), blank=True, null=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('Заявка')
        verbose_name_plural = _('Заявки')
