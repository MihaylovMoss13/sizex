# -*- coding:utf-8 -*-

import zlib
import requests
import redis

from celery import task
from telegram_send import send
from django.conf import settings


DESKTOP_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'
MOBILE_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1'

rds = redis.Redis(**settings.CACHE_REDIS)
CACHE_TTL = 60 * 60 * 24 * 30

@task()
def offload(host, path, resolution):
    key = 'cache:' + host + path + resolution
    headers = {
        'Offload': 'true',
        'User-Agent': DESKTOP_AGENT
    }

    if resolution == 'mobile':
        headers['User-Agent'] = MOBILE_AGENT

    resp = requests.get('http://' + host + path, headers=headers)
    if resp.status_code == 200:
        rds.set(key, zlib.compress(resp.text.encode('utf8')), CACHE_TTL)



@task
def tsend(messages):
    send(messages=messages, parse_mode='html', conf='/etc/telegram/telegram.conf')
