VERSION = (5, 5, 0)
__version__ = '.'.join(map(str, VERSION))
