# -*- coding:utf-8 -*-

from django.contrib import admin
from django.conf import settings
from django.utils.translation import ugettext as _
from django_mptt_admin.admin import DjangoMpttAdmin
from mptt.admin import DraggableMPTTAdmin

from pages.models import Pages, Redirect, Domain, Feedback


class CustomMpttAdmin(DjangoMpttAdmin):
    def move_view(self, request, object_id):
        result = super(CustomMpttAdmin, self).move_view(request, object_id)
        instance = self.get_object(request, admin.utils.unquote(object_id))
        instance.save()
        return result


@admin.register(Pages)
class PagesAdmin(DraggableMPTTAdmin):
    list_display = ('tree_actions', 'indented_title', 'status', 'clear_cache')

    actions = ['select_domain']

    def select_domain(modeladmin, request, queryset):
        queryset.update(domain=settings.DOMAINS[0][0])
    select_domain.short_description = _('Select first domain')

    list_filter = ('created_at',)
    fieldsets = (
        (None, {
            'fields': ('name', 'h1', 'parent', 'text', 'status', 'domain')
        }),
        (_('Meta'), {
            'fields': ('alias', 'replace', 'title', 'meta_d')
        }),
    )

    class Media:
        css = {
            'all': ('admin/css/translation.css',)
        }


@admin.register(Redirect)
class RedirectAdmin(admin.ModelAdmin):
    list_display = ('domain', 'fr', 'to', 'code')
    search_fields = ('fr', 'to')


@admin.register(Domain)
class DomainAdmin(admin.ModelAdmin):
    pass


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    list_display_links = ('id', 'name')
