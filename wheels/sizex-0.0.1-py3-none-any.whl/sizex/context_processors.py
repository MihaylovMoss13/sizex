# -*- coding:utf-8 -*-

import datetime

from pages.models import Pages
from django.utils import translation
from django.conf import settings


def app(request):
    context = {
        'DEBUG': settings.DEBUG,
        'YEAR': datetime.date.today().year,
        'CDN_DOMAIN': settings.CDN_DOMAIN,
        'CONTACTS': settings.CONTACTS,
    }

    try:
        top_menu = Pages.objects.filter(name=u'Верхнее меню').first()
        if top_menu:
            context.update({'top_menu': top_menu.get_children().filter(status=True)})
    except Pages.DoesNotExist:
        pass

    try:
        left_menu = Pages.objects.filter(name=u'Левое меню').first()
        if left_menu:
            context.update({'left_menu': left_menu.get_children().filter(status=True)})
    except Pages.DoesNotExist:
        pass

    return context
