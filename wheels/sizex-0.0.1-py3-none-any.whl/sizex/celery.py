import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sizex.settings')

from django.conf import settings

app = Celery('sizex')
app.conf.update(
    BROKER_URL="redis://localhost:6379/4",
    CELERY_TIMEZONE='Europe/Moscow',
    CELERY_ENABLE_UTC=True,
    CELERYBEAT_SCHEDULER='djcelery.schedulers.DatabaseScheduler',
)
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)
