# coding: utf-8

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch  # noqa
